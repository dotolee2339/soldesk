package a1221;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class ConsoleBoard {
	//아래와 같은 형식으로 etc, post폴더 위치 지정
	static String etcfolder = "C:\\Users\\sdedu\\Desktop\\Java\\a1221\\etc\\";
	static String postfolder = "C:\\Users\\sdedu\\Desktop\\Java\\a1221\\posts\\";
	
	public static int filecnt = 0;
	public static int postcnt = 0;
	public static int pagecnt = 1;
	public static int page = 1;
	public static String username = "root";
	
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String interface_txt = etcfolder + "interface.txt";
		String cmd = "";
		
		//posts 폴더 내 게시글 몇개 있는지 확인
		File dir = new File(postfolder);
		File[] files = dir.listFiles();
		
		for (int i = 0; i < files.length; i++) {
			File file = files[i];

			if (file.isFile()) {
				BufferedReader br = new BufferedReader(new FileReader(file));
				String line;
			
				filecnt++;
				line = br.readLine();
				if (line.equals("true")) continue;
				postcnt++;
			}
		}
		
		
		//게시판
		enter50();
		while (true) {
			//페이지당 게시글 10개 노출, 총 페이지 수 결정
			if (postcnt == 0) pagecnt = 1;
			else pagecnt = (postcnt - 1) / 10 + 1;
			//게시글 수 5 -> (5 - 1) / 10 + 1 = 1		총 1페이지
			//게시글 수 15 -> (15 - 1) / 10 + 1 = 2	총 2페이지
			//게시글 수 30 -> (30 - 1) / 10 + 1 = 3	총 3페이지
			
			printscreen(interface_txt);
			viewinterface();
			System.out.print("\n커맨드 입력 (도움말 : /help) : ");
			cmd = sc.nextLine();

			if (runcommand(cmd) == 0) break;
		}
		
		sc.close();
	}
	
	//커맨드별 switch-case
	static int runcommand(String cmd) throws IOException {
		Scanner sc = new Scanner(System.in);
		switch (cmd) {
		case "/help":
			help();
			
			sc.nextLine();
			enter50();
			return 1;
			
		case "/write":
			write();
			
			enter50();
			return 1;
			
		case "/edit":
			edit();
			
			sc.nextLine();
			enter50();
			return 1;
			
		case "/view":
			view();
			
			sc.nextLine();
			enter50();
			return 1;
			
		case "/remove":
			remove();
			
			sc.nextLine();
			enter50();
			return 1;
			
		case "/page":
			page();
			
			sc.nextLine();
			enter50();
			return 1;
			
		case "/username":
			username();
			
			sc.nextLine();
			enter50();
			return 1;
			
		case "/exit":
			System.out.println("프로그램 종료");
			return 0;
		}
		System.out.println("알 수 없는 명령어입니다. 엔터키를 누르면 메인으로 돌아갑니다.");
		
		sc.nextLine();
		enter50();
		return -1;
	}
	
	static void help() {
		/*
		 * command list
		 * help 
		 * write
		 * edit
		 * view
		 * remove
		 * page
		 * username
		 * exit
		 * 
		 */
		enter50();
		String help = etcfolder + "help.txt";
		printscreen(help);
		System.out.println();
	}
	
	//게시글 작성
	static void write() throws IOException {
		Scanner sc = new Scanner(System.in);
		String title;
		
		postcnt++;
		filecnt++;
		
		System.out.print("게시글 제목 입력 (영문,숫자 최대 15자) : ");
		title = sc.nextLine();
		if (title.length() >= 15) title = title.substring(0, 15);
		
		//파일을 생성된 순서대로 오름차순 정렬
		String filename = "";
		int tmp = filecnt;
		
		//파일 이름
		//예시 (26번째 파일) : z.txt
		//예시 (27번째 파일) : za.txt 
		while (tmp > 0) {
			if (tmp >= 26) filename += (char)122;	//'z'
			else filename += (char)(tmp % 26 + 96);	//'a'~'y'
			
			tmp -= 26;
		}
		
		
		String uri = postfolder + filename + ".txt";
		BufferedWriter bw = new BufferedWriter(new FileWriter(uri));
		
		bw.write("false");	//삭제여부
		bw.newLine();
		bw.write(filecnt + "");  //No.
		bw.newLine();
		bw.write(username);	//ID
		bw.newLine();
		bw.write(LocalDate.now().toString());	//Date
		bw.newLine();
		bw.write(title);	//Title
		bw.newLine();

		System.out.println("게시글 내용 입력 (/wq를 입력하여 종료)");
		while (true) {
			String s;
			s = sc.nextLine();
			if(s.equals("/wq")) break;
			
			bw.write(s);
			bw.newLine();
		}
		bw.close();
	}
	
	//게시글 찾기. ID값으로 찾음. edit, remove에서 사용됨
	static File find(String tgt) throws IOException {
		File dir = new File(postfolder);
		File[] files = dir.listFiles();
		
		for (int i = 0; i < files.length; i++) {
			File file = files[i];
			if (file.isFile()) {
				BufferedReader br = new BufferedReader(new FileReader(file));
				String line;
				
				line = br.readLine();
				if (line.equals("true")) continue;
				line = br.readLine();
				if (line.equals(tgt)) {
					br.close();
					return file;
				}
				br.close();
			}
		}
		
		return null;
	}
	
	//게시글 수정
	static void edit() throws IOException {
		Scanner sc = new Scanner(System.in);
		String editnum;
		
		System.out.println("수정할 글 번호 입력 : ");
		editnum = sc.nextLine();
		
		File file = find(editnum);
		
		if (file == null) {
			System.out.println("파일이 존재하지 않습니다. 엔터키를 누르면 메인으로 돌아갑니다.");
			return;
		}
		else {
			BufferedReader br = new BufferedReader(new FileReader(file));
			
			String isDeleted = br.readLine();
			String No = br.readLine();
			String ID = br.readLine();
			String Date = br.readLine();
			
			br.close();
			
			System.out.print("게시글 제목 입력 (영문,숫자 최대 15자) : ");
			String title = sc.nextLine();
			if (title.length() >= 15) title = title.substring(0, 15);
			
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));

			bw.write(isDeleted);	//isDeleted
			bw.newLine();
			bw.write(No);  //No.
			bw.newLine();
			bw.write(ID);	//ID
			bw.newLine();
			bw.write(Date);	//Date
			bw.newLine();
			bw.write(title);	//Title
			bw.newLine();
			
			System.out.println("게시글 내용 입력 (/wq를 입력하여 종료)");
			while (true) {
				String s;
				s = sc.nextLine();
				if(s.equals("/wq")) break;
				
				bw.write(s);
				bw.newLine();
			}
			bw.close();
			System.out.println("게시글 수정 완료. 엔터키를 누르면 메인으로 돌아갑니다.");
		}
	}
	
	//게시글 열람
	static void view () throws IOException {
		Scanner sc = new Scanner(System.in);
		String viewnum;

		
		System.out.println("열람할 글 번호 입력 : ");
		viewnum = sc.nextLine();
		
		File file = find(viewnum);
		
		if (file == null) {
			System.out.println("파일이 존재하지 않습니다. 엔터키를 누르면 메인으로 돌아갑니다.");
			return;
		}
		else {
			try {
				enter50();
				BufferedReader br = new BufferedReader(new FileReader(file));
				String line;
				
				System.out.println("━━━━━━━━━━━━━━━");
				
				//isDeleted
				line = br.readLine();
				
				//No.
				line = br.readLine();
				
				//ID
				line = br.readLine();
				System.out.println("작성자 : " + line);
				
				//Date
				line = br.readLine();
				System.out.println("작성일 : " + line);
				
				//Title
				line = br.readLine();
				System.out.println("제목 : " + line);
				
				System.out.println("━━━━━━━━━━━━━━━");
				
				while((line = br.readLine()) != null) {
					System.out.println(line);
				}
				
				System.out.println("━━━━━━━━━━━━━━━");
				System.out.println("엔터키를 누르면 메인으로 돌아갑니다.");
				
				br.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	//게시글 삭제
	//파일을 삭제하는 것이 아닌, isDeleted값만 true로 바꿈.
	//isDeleted 값은 파일 내 첫 행에 표시됨.
	static void remove() throws IOException {
		Scanner sc = new Scanner(System.in);
		String removenum;
		
		System.out.println("삭제할 글 번호 입력 : ");
		removenum = sc.nextLine();
		
		File file = find(removenum);
		
		if (file == null) {
			System.out.println("파일이 존재하지 않습니다. 엔터키를 누르면 메인으로 돌아갑니다.");
			return;
		}
		else {
			ArrayList<String> list = new ArrayList<String>();
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;
			
			while((line = br.readLine()) != null) {
				list.add(line);
			}
			br.close();
			
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			
			bw.write("true");
			bw.newLine();
			for (int i = 1; i < list.size(); i++) {
				bw.write(list.get(i));
				bw.newLine();
			}
			bw.close();
			
			postcnt--;
			System.out.println("게시글 삭제 완료. 엔터키를 누르면 메인으로 돌아갑니다.");
		}
	}
	
	static void page() {
		Scanner sc = new Scanner(System.in);
		int pagenum;
		
		System.out.print("이동할 페이지 번호 입력 : ");
		pagenum = sc.nextInt();
		
		if (pagenum < 1 || pagenum > pagecnt) {
			System.out.println("유효하지 않은 페이지 번호입니다. 엔터키를 누르면 메인으로 돌아갑니다.");
			return;
		}
		page = pagenum;
		System.out.println("페이지 " + page + "로 이동됨. 엔터키를 누르면 메인으로 돌아갑니다.");
	}
	
	static void username() {
		Scanner sc = new Scanner(System.in);
		String newname;
		
		System.out.println("바꿀 닉네임 입력 (영문,숫자 최대 8자) : ");
		newname = sc.nextLine();
		if (newname.length() >= 15) newname = newname.substring(0, 15);
		
		username = newname;
		System.out.println("닉네임 변경 성공. 바뀐 닉네임 : " + username);
		System.out.println("엔터키를 누르면 메인으로 돌아갑니다.");
	}
	
	//interface.txt 이후 내용
	static void viewinterface() {
		File dir = new File(postfolder);
		File[] files = dir.listFiles();

		System.out.println();
		
		int continued = 0;
		int displayed = 0;
		for (int i = files.length - 1; i >= 0; i--) {
			File file = files[i];
			if (file.isFile()) {
				if (displayed == 10) break;	//페이지당 게시글 10개 노출
				
				try {
					BufferedReader br = new BufferedReader(new FileReader(file));
					String line;
					
					//isDeleted
					//삭제된 게시물은 아예 세지 않고 넘어감
					line = br.readLine();
					if (line.equals("true")) continue;
					
					if (continued < (page - 1) * 10) { //ex) 2페이지면 게시글 10개 스킵
						continued++;
						continue;
					}
					//조건에 부합해서 출력됨
					displayed++;
					
					//No.
					line = br.readLine();
					System.out.print("┃");
					System.out.printf("%4s", line);
					
					//ID
					line = br.readLine();
					System.out.print("┃");
					System.out.printf("%8s", line);
					
					//Date
					line = br.readLine();
					System.out.print("┃");
					System.out.print(line);
					
					//Title
					line = br.readLine();
					System.out.print("┃");
					System.out.printf("%-15s", line);
					System.out.print("┃");
					
					System.out.println();
					
					if (displayed == 10 || i == 0) 
						System.out.println("┣━━━━┻━━━━━━━━┻━━━━━━━━━━┻━━━━━━━━━━━━━━━┫");
					else
						System.out.println("┣━━━━╋━━━━━━━━╋━━━━━━━━━━╋━━━━━━━━━━━━━━━┫");
					
					br.close();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (postcnt == 0) System.out.println("┣━━━━┻━━━━━━━━┻━━━━━━━━━━┻━━━━━━━━━━━━━━━┫");
		
		System.out.print("┃<Page :");
		System.out.printf("%3d", page);
		System.out.printf("/%3d", pagecnt);
		System.out.println(">                         ┃");
		System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
		
		/*
		┣━━━━┻━━━━━━━━┻━━━━━━━━━━┻━━━━━━━━━━━━━━━┫
		┃<페이지 : 1/1>                            ┃
		┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
		 */
	}
	
	//파일 내용 그대로 출력
	static void printscreen(String uri) {
		try {
			FileInputStream displayStream = new FileInputStream(uri);
			
			byte[] readBuffer = new byte[displayStream.available()];
			
			while (displayStream.read(readBuffer) != -1);
			System.out.print(new String(readBuffer));
			
			displayStream.close();
			
		} catch (Exception e) {
			e.getStackTrace();
		}
	}
	
	//엔터 50번 치기
	static void enter50() {
		for (int i = 0; i < 50; i++) System.out.println();
	}
}
